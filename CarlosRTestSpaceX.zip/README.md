Steps to run project.

1st: Go to terminal project root directory
2nd: run command : npm install
3rd: run command: npm run dev
4th: open browser and go to address localhost:5173 or the one provided by the terminal.

